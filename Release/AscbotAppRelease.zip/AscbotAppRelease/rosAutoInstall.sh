#!/bin/bash

echo "this version is 1.0.3,update time 20190912"
echo "this shell must put in the catkin_ws of folder"
echo "=====================start========================"
CATKIN_CREATE_PKG=/usr/bin
CATKIN_MAKE=/opt/ros/kinetic/bin
CCATKIN_WS="catkin_ws"
PHONE_TALKER_CELL=phone_talker
MOTOR_CELL="motor"
OLED_CELL="oled"
ROSLOG_CELL="roslog"
checkFuctionCell(){
    echo $#
    fuction_cell=$1
    currentPath=$(cd `dirname $0`; pwd)
    echo $currentPath
    echo $fuction_cell

    if [[ $fuction_cell = $MOTOR_CELL   ||  $fuction_cell = $OLED_CELL   ||   $ROSLOG_CELL = $fuction_cell ]];
    then
        #echo $1 "already exist"
        if [ -e $currentPath/AscbotSource/$fuction_cell ];
        then
            echo "'$fuction_cell' is copying "   
            cp -r $currentPath/AscbotSource/$fuction_cell $currentPath/../src
            return 0 
        else
            echo "maybe '$1 ' of path is not correct"  
            return -1  
        fi
    else
        rm devel/lib/phone_talker/phone_talker_node
        if [ -e $currentPath/AscbotSource/$fuction_cell ];
        then
            echo $1 "already exist"
            echo "'$fuction_cell' is copying "
            cp -r $currentPath/AscbotSource/$fuction_cell $currentPath/../src
            return 0
        else
             echo "'$fuction_cell' is copying "
             cp -r $currentPath/AscbotSource/$fuction_cell $currentPath/../src
             return 0

        fi
    fi

    return 0

}
FOLDER_NAME=`pwd | awk -F "/" '{print $NF}'`
echo "start installing"
echo "current folder is  $FOLDER_NAME"
if [ "$FOLDER_NAME"="$CCATKIN_WS" ];
then 
    
    echo "create config file"
    touch modelConfig.txt    
    
    echo "start installing cameraservice"
    if [ $? -eq 0 ];
    then
#    ls | grep "updateRos/cameraservice"
       if [ -e ./AscbotCameraRtspService/cameraservice  ];
       then
            if [ ! -e /home/HwHiAiUser/HIAI_PROJECTS/ascend_workspace/ ];
            then               
                mkdir -p /home/HwHiAiUser/HIAI_PROJECTS/ascend_workspace/
            fi
            cd /home/HwHiAiUser/HIAI_PROJECTS/ascend_workspace/
            rm -r cameraservice
            cp -vr /root/home/catkin_ws/AscbotAppRelease/AscbotCameraRtspService/cameraservice ./
            cd -
        else
            echo "cameraservice update package not find"
            exit 1
        fi
    else
       echo "not find folder of cameraservice"
       exit 1
    fi
    echo "cameraservice install success"




    echo "ros work space already create"
    checkFuctionCell  phone_talker
    if [ $? != 0 ] ;
    then
        echo "'$PHONE_TALKER_CELL' operate failed "
    else
        echo "'$PHONE_TALKER_CELL' operate success "
    fi  
    checkFuctionCell  $MOTOR_CELL
    if [ $? != 0 ] ;
    then
        echo "'$MOTOR_CELL' operate failed  "
    else
        echo "'$MOTOR_CELL' operate success "
    fi
    checkFuctionCell  $OLED_CELL
    if [ $? != 0 ] ;
    then
        echo "'$OLED_CELL' operate failed  "
    else
        echo "'$OLED_CELL' operate success " 
    fi
    checkFuctionCell  $ROSLOG_CELL
    if [ $? != 0 ] ;
    then
        echo "'$ROSLOG_CELL' operate failed  "
    else
        echo "'$ROSLOG_CELL' operate  success "
    fi
    cd ..
    $CATKIN_MAKE/catkin_make clean
     $CATKIN_MAKE/catkin_make
    cd -
    echo "start source some bashrc"
    source /opt/ros/kinetic/setup.bash
    source /root/home/catkin_ws/devel/setup.bash
    echo "source end"
    echo "all program installed,you can test all"
    echo "tips!!!!!!!! you try to deal this command what commanc is 'source /root/home/catkin_ws/devel/setup.bash' in the terminal by yourself"
    echo "=====================end========================"
else
    echo "error,ros work space is not exist!!!!!"
    exit -1
fi
chmod 777 fixStartup*
./fixStartupOptions.sh 2
echo "tips!!  ok, you can reboot."
:<<EOF
/root/home/catkin_ws
root@davinci-mini:~/home/catkin_ws# ls /opt/ros/kinetic/setup.bash 
/opt/ros/kinetic/setup.bash
root@davinci-mini:~/home/catkin_ws# ls devel/setup.bash 
devel/setup.bash
root@davinci-mini:~/home/catkin_ws# 
EOF
