#!/bin/bash


echo "print params $1"
if [ $# == 1 ] ;then
   if [ $1 == 1 ]; then
       #first ,close the rc.local 
       grep "checkProcess.sh" /etc/rc.local
       if [ $? == 0 ];then
       
           sed  -ie '/checkProcess.sh/s/^/#/g'  /etc/rc.local
       fi
   elif [ $1 == 2 ]; then
       #first ,close the rc.local 
       grep "checkProcess.sh" /etc/rc.local
       if [ $? == 0 ];then
 
             
           sed  -ie '/checkProcess.sh/s/^#//g'  /etc/rc.local
       else
#          echo  "/home/HwHiAiUser/HIAI_PROJECTS/ascend_workspace/cameraservice/checkProcess.sh  &" >> /etc/rc.local    
          sec -i '$i /home/HwHiAiUser/HIAI_PROJECTS/ascend_workspace/cameraservice/checkProcess.sh  &'
       fi
   fi  

else
    echo "when you use this shell, it must cantain 1 params "
fi
