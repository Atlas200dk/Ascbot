#!/bin/bash
while true
do

ps -fe | grep rtsp-server | grep -v grep
if [ $? -ne 0 ]
then
echo "start process"
export LD_LIBRARY_PATH=/home/HwHiAiUser/HIAI_PROJECTS/ascend_workspace/cameraservice:$LD_LIBRARY_PATH

cd /home/HwHiAiUser/HIAI_PROJECTS/ascend_workspace/cameraservice
chmod 777 ./*
./rtsp-server &
cd -
else
echo "rtsp-server process is  running  "
fi

sleep 2
ps -fe | grep camera_server | grep -v grep
if [ $? -ne 0 ]
then
echo "start process"
export LD_LIBRARY_PATH=/home/HwHiAiUser/HIAI_PROJECTS/ascend_workspace/cameraservice:$LD_LIBRARY_PATH
chmod 777 ./*
cd /home/HwHiAiUser/HIAI_PROJECTS/ascend_workspace/cameraservice
./camera_server &
cd -
else 
echo "camera_server process is running  "
fi

source /opt/ros/kinetic/setup.bash
source /root/home/catkin_ws/devel/setup.bash


export ROS_MASTER_URI=http://127.0.0.1:11311
export ROS_HOSTNAME=127.0.0.1

ps -fe | grep roscore* | grep -v grep
if [ $? -ne 0 ]
then
echo "start process"
roscore &

else
echo "roscore process is running  "
fi
sleep 4


echo "************test************* "
ps -fe | grep "motorSubcriber.py" | grep -v grep 
echo "************test************* "
ps -aux | grep "motorSubcriber.py" | grep -v grep
if [ $? -ne 0 ]
then
    echo "start process"
    rosrun motor  motorSubcriber.py & 
else
    echo "motor python process is running  "
fi

ps -aux | grep "oled_node.py" | grep -v grep
if [ $? -ne 0 ]
then
    echo "start process"
    rosrun oled oled_node.py &
else
echo "oled_node python process is running  "
fi


ps -aux | grep "roslog.py" | grep -v grep
if [ $? -ne 0 ]
then
echo "start process"
rosrun roslog roslog.py &
  
else
echo "roslog python process is running  "
fi 

ps -fe | grep phone_talker* | grep -v grep
if [ $? -ne 0 ]
then
echo "start process"
rosrun phone_talker phone_talker_node &

else
echo "phone_talker process is running  "
fi


done

