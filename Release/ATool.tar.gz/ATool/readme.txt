### dependencies

opencv
jsoncpp

```
sudo apt-get install libopencv-dev
sudo apt-get install libjsoncpp-dev
sudo ln -s /usr/include/jsoncpp/json/ /usr/include/json
```

### usage

[Put image to ./ATool/img]
cd build
cmake ..
make
./ATool
