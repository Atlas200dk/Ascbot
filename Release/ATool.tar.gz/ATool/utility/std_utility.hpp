/*
 * Copyright © 2018-2019 Thunder Software Technology Co., Ltd.
 * All rights reserved.
 */

#ifndef TERMINAL_UTILITY_STD_UTILITY_HPP_
#define TERMINAL_UTILITY_STD_UTILITY_HPP_

#include <iomanip>
#include "dirent.h"
#include <string>
#include <cstring>
#include <vector>
#include <regex>
#include "TSLog.h"

namespace ts {

extern void findAllFiles(
        const std::string& path,
        const std::vector<std::string>& suffixes,
        std::vector<std::string>& files,
        std::vector<std::string>* dirs = nullptr);

extern std::vector<std::string> split(
        const std::string& input,
        const std::string& regex);

}

#endif /* TERMINAL_UTILITY_STD_UTILITY_HPP_ */
