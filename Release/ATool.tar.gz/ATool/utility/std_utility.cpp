/*
 * Copyright © 2018-2019 Thunder Software Technology Co., Ltd.
 * All rights reserved.
 */

#include "utility/std_utility.hpp"

void ts::findAllFiles(
        const std::string& path,
        const std::vector<std::string>& suffixes,
        std::vector<std::string>& files,
        std::vector<std::string>* dirs) {
    DIR *dir = nullptr;
    struct dirent *ptr;
    if (NULL == (dir = opendir(path.c_str() ) ) ) {
        LOGW("WARNING: The file path(\"%s\") is invalid!\n", path.c_str() );
        return;
    }
    while (NULL != (ptr=readdir(dir) ) ) {
        if (0 == strcmp(ptr->d_name, ".") || 0 == strcmp(ptr->d_name, "..")) {
            continue;
        } else if (8 == ptr->d_type) { // File.
            std::string tmp_name = ptr->d_name;
            for (size_t i = 0; i < suffixes.size(); i++) {
                if (std::string::npos != tmp_name.find(suffixes[i])) {
                    files.push_back(path + "/" + tmp_name);
                }
            }
        } else if (10 == ptr->d_type) { // Link file.
            continue;
        } else if (4 == ptr->d_type) {
            if (NULL != dirs) {
                dirs->push_back(ptr->d_name);//dir
            }
            findAllFiles(path + "/" + ptr->d_name, suffixes, files, dirs);
        }
    }
    closedir(dir);
    return;
}

std::vector<std::string> ts::split(const std::string& input, const std::string& regex) {
    // passing -1 as the submatch index parameter performs splitting
    std::regex re(regex);
    std::sregex_token_iterator
        first{input.begin(), input.end(), re, -1},
        last;
    return {first, last};
}