#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <TSLog.h>
#include <std_utility.hpp>
#include <opencv2/opencv.hpp>
#include <json/json.h>

std::string img_path = "../img";
std::string label_path = "../label";
cv::Point selected = {-1, -1};
cv::Mat src;
cv::Size src_size;

void on_mouse(int event,int x,int y,int flags,void *ustc) {
    // if (event == cv::EVENT_MOUSEMOVE) {
    //     LOGI("%d, %d", x, y);
    // }
    if (event == cv::EVENT_LBUTTONDOWN) {
        selected.x = x;
        selected.y = y;
    }
    cv::Point start(src.cols / 2, src.rows);
    cv::Mat canvas;
    src.copyTo(canvas);
    if (selected.x >= 0 && selected.y >= 0) {
        cv::line(canvas, start, selected, {0, 255, 255}, 3);
        cv::circle(canvas, selected, 5, {0, 255, 0}, 25);
    }
    cv::line(canvas, start, {x, y}, {255, 255, 0}, 3);
    cv::circle(canvas, {x, y}, 5, {0, 0, 255}, 15);
    cv::imshow("src", canvas);
}

int main() {
    std::vector<std::string> img_paths;
    std::vector<std::string> label_paths;
    cv::namedWindow("src", cv::WINDOW_NORMAL);
    cv::resizeWindow("src", 1280, 720);

    ts::findAllFiles(
            img_path,
            {".jpg", ".JPG", ".PNG", ".png", ".jpeg", ".JPEG", ".bmp", ".BMP"},
            img_paths);
    ts::findAllFiles(
            label_path,
            {".json"},
            label_paths);

    for (auto& path : img_paths) {
        std::string name_with_suffix = ts::split(path, {"/"}).back();
        std::string name = ts::split(name_with_suffix, {"\\."}).front();
        LOGI("Do %s", name.c_str() );
        std::string target_label_file_path = label_path + "/" + name + ".json";
        if (label_paths.end() != std::find(label_paths.begin(), label_paths.end(), target_label_file_path) ) {
            continue;
        }
        src = cv::imread(path);
        src_size = src.size();
        cv::resize(src, src, {1280, 720});
        cv::line(src, {0, 445}, {1280, 445}, {255, 0, 0}, 3);
        cv::imshow("src", src);
        cv::setMouseCallback("src", on_mouse, 0);//调用回调函数
        while ('n' != cv::waitKey() && (selected == cv::Point(-1, -1) ) ) {
            continue;
        }

        cv::Point target_point;
        target_point.x = src_size.width * ((float)selected.x / src.cols );
        target_point.y = src_size.height * ((float)selected.y / src.rows );
        Json::Value array;
        array.append(target_point.x);
        array.append(target_point.y);
        LOGI("Select point: [%d, %d]", target_point.x, target_point.y);

        std::ofstream os;
        Json::FastWriter fw;
        os.open(target_label_file_path);
        os << fw.write(array);
        os.close();
        LOGI("Save to %s", target_label_file_path.c_str() );

        //Reset flag
        selected = {-1, -1};
    }

    LOGI("ByeBye");
    return -1;
}
