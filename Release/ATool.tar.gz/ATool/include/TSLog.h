/*
 * Copyright (c) 2018 Thunder Software Technology Co., Ltd.
 * All rights, including trade secret rights, reserved.
 */

#ifndef INCLUDE_TSLOG_H_
#define INCLUDE_TSLOG_H_

#ifdef ANDROID_TARGET
#include <android/log.h>
#ifndef _TAG
#define _TAG "ATools"
#endif
#ifndef LOGD
#define LOGD(...)  __android_log_print(ANDROID_LOG_DEBUG, _TAG, __VA_ARGS__)
#endif
#ifndef LOGI
#define LOGI(...)  __android_log_print(ANDROID_LOG_INFO,  _TAG, __VA_ARGS__)
#endif
#ifndef LOGE
#define LOGE(...)  __android_log_print(ANDROID_LOG_ERROR, _TAG, __VA_ARGS__)
#endif
#ifndef LOGW
#define LOGW(...)  __android_log_print(ANDROID_LOG_WARN,  _TAG, __VA_ARGS__)
#endif

#else

#include <iostream>
#include <stdio.h>
#include <string>
#include <memory>
#include <mutex>

template <class ...Args>
void COUT_(std::string log_level, const std::string& format_str, Args... args) {
#if 1
    std::string tmp;
    tmp = log_level + ": " + format_str + "\n";
    printf(tmp.c_str(), args...);
#else
    size_t size = snprintf(nullptr, 0, format_str.c_str(), args...) + 1; // Extra space for '\0'
    std::unique_ptr<char[]> buf( new char[ size ] );
    snprintf(buf.get(), size, format_str.c_str(), args...);
    std::string dst( buf.get(), buf.get() + size - 1 ); // We don't want the '\0' inside
    dst = log_level + ": " + dst;
    std::cout << dst << std::endl;
#endif
    return;
}
#ifndef LOGI
#define LOGI(...) COUT_("INFO",    __VA_ARGS__);
#endif
#ifndef LOGD
#define LOGD(...) COUT_("DEBUG",   __VA_ARGS__);
#endif
#ifndef LOGW
#define LOGW(...) COUT_("WARNING", __VA_ARGS__);
#endif
#ifndef LOGE
#define LOGE(...) COUT_("ERROR",   __VA_ARGS__);
#endif

#endif

#ifndef LOGD_IF
#define LOGD_IF(cond, ...) \
    ( ( cond ) \
    ? ((void)LOGD(__VA_ARGS__)) \
    : (void)0 )
#endif

#endif

